# KK FASHION — Starter Website

A responsive React + Vite storefront starter using a charcoal / metallic-gold visual direction.

## Included in this first build
- Responsive homepage and navigation
- Category filters and product search
- Product cards with wishlist toggles
- Working local shopping cart (add, remove/decrease, increase)
- Campaign and brand-story sections
- Firebase initialization placeholder
- Vercel-ready Vite build

## 1. Run locally
Install Node.js (LTS), then in this folder run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`).

## 2. Publish to GitHub
1. Create a new **private** GitHub repository named `kk-fashion`.
2. Upload the contents of this folder (not the outer zip file).
3. Commit the files to the repository's `main` branch.

If using Git on a computer:

```bash
git init
git add .
git commit -m "Initial KK FASHION storefront"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/kk-fashion.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## 3. Deploy on Vercel
1. Sign in to Vercel using GitHub.
2. Import the `kk-fashion` repository.
3. Framework preset: **Vite**.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Deploy, then connect `kkfashion.space` in Vercel's Domains settings.

## 4. Connect Firebase
1. In Firebase Console, open your existing project.
2. Add/register a Web App and copy its web configuration.
3. Copy `.env.example` to `.env.local`.
4. Fill in the `VITE_FIREBASE_*` values.
5. Add the same environment variables in Vercel Project Settings → Environment Variables.

Do not share Firebase service-account JSON, private keys, Razorpay secret keys, or OTP provider secrets. Client-side Firebase web config is not a substitute for Firestore/Storage security rules.

## Important before accepting real orders
This is a visual and interaction starter, not a production-ready store yet. Product records, inventory transactions, real checkout, Razorpay server-side order creation/signature verification, COD order validation, shipping integrations, WhatsApp/SMS/email notifications, admin roles, returns, and tracking still need secure backend implementation and testing. The displayed sample products and prices are placeholders.
