import { useMemo, useState } from "react";
import { ArrowDown, ArrowRight, Search, ShoppingBag, Menu, X, Heart, Instagram, Youtube, MessageCircle, Plus, Minus } from "lucide-react";

const categories = ["All", "Oversized T-Shirts", "Shirts", "Baggy Jeans", "Regular T-Shirts", "Shoes"];
const products = [
  { id: 1, name: "Midnight Oversized Tee", category: "Oversized T-Shirts", price: 899, old: 1299, tag: "BESTSELLER", tone: "tee", color: "Stone black" },
  { id: 2, name: "Urban Utility Shirt", category: "Shirts", price: 1499, old: 1899, tag: "NEW DROP", tone: "shirt", color: "Olive" },
  { id: 3, name: "Wide-Leg Street Denim", category: "Baggy Jeans", price: 1899, old: 2299, tag: "TRENDING", tone: "jeans", color: "Indigo" },
  { id: 4, name: "Essential Boxy Tee", category: "Regular T-Shirts", price: 699, old: 999, tag: "EVERYDAY", tone: "tee2", color: "Off white" },
  { id: 5, name: "Velocity Street Sneakers", category: "Shoes", price: 2499, old: 2999, tag: "LIMITED", tone: "shoe", color: "Black / cream" },
  { id: 6, name: "After Hours Shirt", category: "Shirts", price: 1399, old: 1799, tag: "JUST IN", tone: "shirt2", color: "Charcoal" },
];

function ProductArt({ tone }) {
  return <div className={`product-art ${tone}`} aria-label="Stylized product placeholder">
    <div className="art-glow" />
    <div className="garment">
      <span className="garment-mark">KK</span>
    </div>
    <span className="art-caption">KK / STUDIO</span>
  </div>;
}

export default function App() {
  const [category, setCategory] = useState("All");
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [liked, setLiked] = useState([]);
  const [notice, setNotice] = useState("");

  const visibleProducts = useMemo(() => products.filter(p =>
    (category === "All" || p.category === category) &&
    p.name.toLowerCase().includes(query.toLowerCase())
  ), [category, query]);

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  function addToCart(product) {
    setCart(current => {
      const found = current.find(item => item.id === product.id);
      return found
        ? current.map(item => item.id === product.id ? { ...item, qty: item.qty + 1 } : item)
        : [...current, { ...product, qty: 1 }];
    });
    setNotice(`${product.name} added to your bag`);
    window.setTimeout(() => setNotice(""), 2200);
  }

  function changeQty(id, amount) {
    setCart(current => current
      .map(item => item.id === id ? { ...item, qty: item.qty + amount } : item)
      .filter(item => item.qty > 0));
  }

  return <div className="site-shell">
    <div className="announcement">COMPLIMENTARY SHIPPING ON ALL ORDERS <span>✦</span> PAN INDIA DELIVERY</div>
    <header className="header">
      <button className="icon-btn mobile-menu" aria-label="Open menu" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X/> : <Menu/>}</button>
      <a className="wordmark" href="#home">KK<span>FASHION</span><i>®</i></a>
      <nav className={menuOpen ? "nav nav-open" : "nav"}>
        <a href="#home" onClick={() => setMenuOpen(false)}>HOME</a>
        <a href="#shop" onClick={() => setMenuOpen(false)}>SHOP</a>
        <a href="#collections" onClick={() => setMenuOpen(false)}>COLLECTIONS</a>
        <a href="#about" onClick={() => setMenuOpen(false)}>OUR STORY</a>
      </nav>
      <div className="header-actions">
        <label className="search-box"><Search size={16}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search pieces"/></label>
        <button className="icon-btn bag-btn" aria-label="Open shopping bag" onClick={() => setCartOpen(true)}><ShoppingBag size={19}/><span>{cartCount}</span></button>
      </div>
    </header>

    <main>
      <section className="hero" id="home">
        <div className="hero-grid" />
        <div className="hero-copy">
          <p className="eyebrow"><span className="eyebrow-line"/> THE NEW STREETWEAR STANDARD / 001</p>
          <h1>OWN YOUR<br/><em>OWN</em> LANE.</h1>
          <p className="hero-sub">Built for the ones who move different.<br/>Everyday essentials. Unordinary energy.</p>
          <a className="gold-button" href="#shop">EXPLORE THE DROP <ArrowRight size={16}/></a>
          <div className="hero-foot"><span>KK FASHION / KOTA, INDIA</span><span>EST. FOR THE BOLD</span></div>
        </div>
        <div className="hero-visual">
          <div className="orbit orbit-one"/><div className="orbit orbit-two"/>
          <div className="hero-sculpture">
            <div className="sculpture-top">KK</div>
            <div className="sculpture-main">FASHION</div>
            <div className="sculpture-bottom">YOUR STYLE. YOUR RULES.</div>
          </div>
          <div className="vertical-label">FUTURE / STREET / CULTURE</div>
          <div className="hero-index">01 <span>—</span> 03</div>
        </div>
        <a className="scroll-cue" href="#shop"><span>SCROLL TO DISCOVER</span><ArrowDown size={15}/></a>
      </section>

      <section className="ticker" aria-label="Brand statement"><div>NO RULES. JUST STYLE. <b>✳</b> NO RULES. JUST STYLE. <b>✳</b> NO RULES. JUST STYLE. <b>✳</b></div></section>

      <section className="shop-section section-wrap" id="shop">
        <div className="section-heading">
          <div><p className="eyebrow">CURATED FOR YOUR EVERYDAY</p><h2>THE LATEST <em>DROP.</em></h2></div>
          <p className="section-note">Pieces that speak before you do.<br/>Find your next favourite.</p>
        </div>
        <div className="category-row">
          <div className="category-tabs">{categories.map(c => <button key={c} className={category === c ? "category active" : "category"} onClick={() => setCategory(c)}>{c}</button>)}</div>
          <span className="result-count">0{visibleProducts.length} PIECES</span>
        </div>
        <div className="product-grid">
          {visibleProducts.map((p, i) => <article className="product-card" key={p.id}>
            <div className="product-image-wrap"><ProductArt tone={p.tone}/>
              <span className="product-tag">{p.tag}</span>
              <button className={`wishlist ${liked.includes(p.id) ? "is-liked" : ""}`} aria-label="Add to wishlist" onClick={() => setLiked(old => old.includes(p.id) ? old.filter(id => id !== p.id) : [...old, p.id])}><Heart size={17} fill={liked.includes(p.id) ? "currentColor" : "none"}/></button>
              <button className="quick-add" onClick={() => addToCart(p)}>QUICK ADD <Plus size={14}/></button>
            </div>
            <div className="product-meta"><div><h3>{p.name}</h3><p>{p.color} · {p.category}</p></div><div className="price"><strong>₹{p.price.toLocaleString("en-IN")}</strong><del>₹{p.old.toLocaleString("en-IN")}</del></div></div>
          </article>)}
        </div>
        {visibleProducts.length === 0 && <p className="empty-state">No pieces found. Try another search.</p>}
      </section>

      <section className="campaign" id="collections">
        <div className="campaign-image"><div className="campaign-ring"/><div className="campaign-monogram">KK</div><span>CAMPAIGN / 2026</span></div>
        <div className="campaign-copy"><p className="eyebrow">NOT MADE TO BLEND IN</p><h2>THE CITY<br/>IS YOUR <em>RUNWAY.</em></h2><p>From laid-back layers to statement silhouettes — build a look that feels unmistakably yours.</p><a className="text-link" href="#shop">SHOP THE COLLECTION <ArrowRight size={16}/></a></div>
      </section>

      <section className="manifesto section-wrap" id="about">
        <p className="eyebrow">A DIFFERENT KIND OF EVERYDAY</p>
        <h2>YOUR STYLE.<br/><em>YOUR RULES.</em></h2>
        <p>Streetwear is more than what you wear. It's how you show up. KK FASHION brings together confident fits, clean details and the freedom to make every look your own.</p>
      </section>
    </main>

    <footer className="footer">
      <div className="footer-top"><div><a className="wordmark footer-mark" href="#home">KK<span>FASHION</span><i>®</i></a><p>YOUR STYLE. YOUR RULES.</p></div><div className="footer-links"><a href="#shop">Shop</a><a href="#collections">Collections</a><a href="#about">About us</a><a href="mailto:support@kkfashion.space">Contact</a></div><div className="socials"><a href="#" aria-label="Instagram"><Instagram/></a><a href="#" aria-label="YouTube"><Youtube/></a><a href="#" aria-label="WhatsApp"><MessageCircle/></a></div></div>
      <div className="footer-bottom"><span>© 2026 KK FASHION. ALL RIGHTS RESERVED.</span><span>MADE FOR YOUR OWN LANE.</span><span>KOTA, RAJASTHAN / INDIA</span></div>
    </footer>

    {notice && <div className="toast">{notice}</div>}
    {cartOpen && <div className="drawer-backdrop" onClick={() => setCartOpen(false)}>
      <aside className="cart-drawer" onClick={e => e.stopPropagation()}>
        <div className="drawer-head"><div><p className="eyebrow">YOUR SELECTION</p><h2>YOUR BAG <span>({cartCount})</span></h2></div><button className="icon-btn" onClick={() => setCartOpen(false)} aria-label="Close cart"><X/></button></div>
        {cart.length === 0 ? <div className="empty-cart"><ShoppingBag size={34}/><h3>Your bag is waiting.</h3><p>Find something that feels like you.</p><button className="gold-button" onClick={() => setCartOpen(false)}>CONTINUE SHOPPING <ArrowRight size={15}/></button></div> :
          <><div className="cart-items">{cart.map(item => <div className="cart-item" key={item.id}><div className="cart-thumb"><ProductArt tone={item.tone}/></div><div className="cart-item-info"><h3>{item.name}</h3><p>₹{item.price.toLocaleString("en-IN")}</p><div className="qty-control"><button onClick={() => changeQty(item.id, -1)}><Minus size={13}/></button><span>{item.qty}</span><button onClick={() => changeQty(item.id, 1)}><Plus size={13}/></button></div></div></div>)}</div><div className="cart-total"><div><span>Subtotal</span><strong>₹{total.toLocaleString("en-IN")}</strong></div><p>Complimentary shipping on all orders.</p><button className="gold-button full" onClick={() => setNotice("Checkout integration is the next build step.")}>PROCEED TO CHECKOUT <ArrowRight size={16}/></button></div></>}
      </aside>
    </div>}
  </div>;
}