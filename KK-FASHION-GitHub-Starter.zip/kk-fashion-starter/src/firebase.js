import { initializeApp, getApps } from "firebase/app";

// Firebase is intentionally optional until your own project config is added.
// Copy .env.example to .env.local and fill in the Firebase Web App values.
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export const firebaseApp =
  firebaseConfig.apiKey && firebaseConfig.projectId
    ? (getApps().length ? getApps()[0] : initializeApp(firebaseConfig))
    : null;